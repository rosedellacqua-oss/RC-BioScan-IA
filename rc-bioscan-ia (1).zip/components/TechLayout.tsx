import React, { ReactNode } from 'react';
import { Scan, Activity, Cpu, ShieldCheck } from 'lucide-react';

interface TechLayoutProps {
  children: ReactNode;
  status: string;
}

const TechLayout: React.FC<TechLayoutProps> = ({ children, status }) => {
  return (
    <div className="min-h-screen bg-[#020617] text-slate-200 tech-grid selection:bg-amber-500/30 overflow-x-hidden">
      {/* Top Header */}
      <header className="fixed top-0 w-full z-50 glass-panel border-b border-blue-900/50 h-16 flex items-center justify-between px-6">
        <div className="flex items-center gap-3">
          <div className="relative w-8 h-8 flex items-center justify-center">
            <Scan className="w-8 h-8 text-amber-400 absolute animate-spin-slow" />
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
          </div>
          <div>
            <h1 className="font-display font-bold text-xl tracking-wider text-white">
              RC<span className="text-amber-400">-BioScan</span> IA
            </h1>
            <p className="text-[10px] text-blue-400 tracking-[0.2em] uppercase">Human Trichology System</p>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-8">
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-slate-500 uppercase font-mono">Status do Sistema</span>
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${status === 'ERROR' ? 'bg-red-500' : 'bg-emerald-500 animate-pulse'}`}></span>
              <span className="text-sm font-mono text-emerald-400">{status}</span>
            </div>
          </div>
          <div className="border-l border-slate-700 h-8"></div>
          <div className="flex gap-4 text-slate-400">
            <Cpu size={18} />
            <Activity size={18} />
            <ShieldCheck size={18} />
          </div>
        </div>
      </header>

      {/* Side Decorations */}
      <div className="fixed left-0 top-1/2 -translate-y-1/2 w-12 hidden lg:flex flex-col gap-4 items-center opacity-30">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="w-1 h-12 bg-blue-900 rounded-full"></div>
        ))}
      </div>
      
      <div className="fixed right-0 top-1/2 -translate-y-1/2 w-12 hidden lg:flex flex-col gap-4 items-center opacity-30">
        <div className="writing-vertical text-xs font-mono tracking-widest text-amber-500/50 transform rotate-180">
          DIAGNOSTIC SEQUENCE 045-A
        </div>
      </div>

      {/* Main Content */}
      <main className="pt-24 pb-12 px-4 md:px-8 max-w-7xl mx-auto min-h-screen relative z-10">
        {children}
      </main>

      {/* Footer decorative line */}
      <div className="fixed bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-amber-500/50 to-transparent"></div>
    </div>
  );
};

export default TechLayout;