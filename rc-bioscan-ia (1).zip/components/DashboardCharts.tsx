import React from 'react';
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell
} from 'recharts';
import { HairAnalysisData } from '../types';

interface DashboardChartsProps {
  data: HairAnalysisData;
}

export const HealthRadar: React.FC<{ data: HairAnalysisData }> = ({ data }) => {
  const chartData = [
    { subject: 'Densidade', A: data.densityScore, fullMark: 100 },
    { subject: 'Espessura', A: data.thicknessScore, fullMark: 100 },
    { subject: 'Hidratação', A: data.hydrationScore, fullMark: 100 },
    { subject: 'Saúde Couro', A: data.scalpHealthScore, fullMark: 100 },
    { subject: 'Vitalidade', A: data.overallHealthScore, fullMark: 100 },
  ];

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="70%" data={chartData}>
          <PolarGrid stroke="#1e293b" />
          <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 10, fontFamily: 'Orbitron' }} />
          <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
          <Radar
            name="Paciente"
            dataKey="A"
            stroke="#fbbf24"
            strokeWidth={2}
            fill="#fbbf24"
            fillOpacity={0.2}
          />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};

export const MetricBars: React.FC<{ data: HairAnalysisData }> = ({ data }) => {
  const chartData = [
    { name: 'DENS', value: data.densityScore },
    { name: 'ESP', value: data.thicknessScore },
    { name: 'HIDR', value: data.hydrationScore },
    { name: 'SAÚDE', value: data.scalpHealthScore },
  ];

  return (
    <div className="h-40 w-full mt-4">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={chartData}>
          <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 10 }} axisLine={false} tickLine={false} />
          <YAxis hide domain={[0, 100]} />
          <Tooltip 
            contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f1f5f9' }}
            cursor={{fill: 'rgba(255,255,255,0.05)'}}
          />
          <Bar dataKey="value" radius={[2, 2, 0, 0]}>
            {chartData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.value > 70 ? '#10b981' : entry.value > 40 ? '#fbbf24' : '#ef4444'} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};