import React from 'react';

const ScanningEffect: React.FC = () => {
  return (
    <div className="absolute inset-0 pointer-events-none z-20 overflow-hidden rounded-lg">
      <div className="absolute inset-0 border-2 border-amber-500/30 rounded-lg"></div>
      <div className="scanner-line h-[2px] w-full bg-amber-400 shadow-[0_0_15px_rgba(251,191,36,0.8)] absolute"></div>
      <div className="absolute top-2 right-2 text-[10px] text-amber-400 font-mono animate-pulse">
        AQUISICÃO DE DADOS...
      </div>
      <div className="absolute bottom-2 left-2 text-[10px] text-blue-400 font-mono">
        SENSOR ÓPTICO: ATIVO
      </div>
      
      {/* Grid overlay */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(14,165,233,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(14,165,233,0.1)_1px,transparent_1px)] bg-[size:20px_20px]"></div>
      
      {/* Crosshairs */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 border border-amber-500/50 opacity-50"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1 h-2 bg-amber-500"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-1 bg-amber-500"></div>
    </div>
  );
};

export default ScanningEffect;