import { GoogleGenAI, Type } from "@google/genai";
import { HairAnalysisData } from "../types";

// Fallback mock data in case of API failure or demo mode
const MOCK_DATA: HairAnalysisData = {
  densityScore: 78,
  thicknessScore: 65,
  hydrationScore: 45,
  scalpHealthScore: 82,
  overallHealthScore: 68,
  condition: "Moderadamente Saudável",
  detectedIssues: ["Leve ressecamento", "Foliculite inicial", "Variação de espessura"],
  recommendations: [
    "Hidratação profunda com aminoácidos",
    "Tônico para fortalecimento do bulbo",
    "Evitar água em alta temperatura",
    "Laserterapia de baixa potência recomendada"
  ],
  technicalSummary: "A tricoscopia digital revela uma densidade folicular satisfatória, porém observa-se afinamento progressivo em 15% das hastes analisadas. O couro cabeludo apresenta leve eritema perifolicular."
};

export const analyzeHairImage = async (base64Image: string): Promise<HairAnalysisData> => {
  const apiKey = process.env.API_KEY;

  if (!apiKey) {
    console.warn("API Key missing, returning mock data.");
    // Simulate delay
    await new Promise(resolve => setTimeout(resolve, 3000));
    return MOCK_DATA;
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    
    // Clean base64 string if necessary (remove data:image/png;base64, prefix)
    const data = base64Image.split(',')[1] || base64Image;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash", // Good balance of speed and vision capability
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: data
            }
          },
          {
            text: `Analyze this microscopic image of human hair and scalp (trichoscopy). 
            Perform a technical diagnosis suitable for a hair clinic (RC-BioScan).
            Focus strictly on HUMAN hair. 
            Provide scores from 0-100 for Density, Thickness, Hydration, and Scalp Health.
            List specific dermatological observations and professional recommendations.
            Format output as JSON.`
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            densityScore: { type: Type.INTEGER },
            thicknessScore: { type: Type.INTEGER },
            hydrationScore: { type: Type.INTEGER },
            scalpHealthScore: { type: Type.INTEGER },
            overallHealthScore: { type: Type.INTEGER },
            condition: { type: Type.STRING },
            detectedIssues: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING } 
            },
            recommendations: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING } 
            },
            technicalSummary: { type: Type.STRING }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as HairAnalysisData;
    }
    
    throw new Error("Empty response from AI");

  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    // Return mock data if analysis fails to ensure UI continuity in demo
    return MOCK_DATA;
  }
};